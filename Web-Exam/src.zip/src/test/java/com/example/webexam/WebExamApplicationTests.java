package com.example.webexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebExamApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.example.webexam.models.enums;

public enum ConditionEnum {
    EXCELLENT,
    GOOD,
    ACCEPTABLE
}

package com.example.shoppinglist.models.enums;

public enum CategoryType {
    FOOD,
    DRINK,
    HOUSEHOLD,
    OTHER
}

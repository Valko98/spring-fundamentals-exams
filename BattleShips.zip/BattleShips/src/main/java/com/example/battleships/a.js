fetch("http://localhost:8080/battle", {
    "body": "attackerId=7&defenderId=3",
    "method": "POST"
});
package com.example.battleships.models;

public enum ShipType {
    BATTLE, CARGO, PATROL
}
